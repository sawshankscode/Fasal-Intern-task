<?php include'../db/config.php';
session_start();

if(isset($_POST['register'])){

$name=htmlentities($_POST["uname"]);
$email=htmlentities($_POST['email']);
$pass1=htmlentities($_POST['pass1']);
$pass2=htmlentities($_POST['pass2']);






if($pass1==$pass2){
    $password=md5($pass1);

    $check="select email from user where email='$email'";
    $resultcheck=$conn->query($check);
if($resultcheck->num_rows>0){
    $_SESSION['msg']="User Already Exist with this email";
    $_SESSION['type']="warning";
    header('location:../register.php');
  
}else{
    $sql="insert into user (name,email,password) Values('$name','$email','$password')";
    $result = $conn->query($sql);
if($result){
    $_SESSION['msg']="User Created Successfully";
    $_SESSION['type']="success";
    header('location:../');
}
else{
    $_SESSION['msg']="Sorry! There is Some Technical Issue !";
    $_SESSION['type']="danger";
    header('location:../register.php');
} 
}

}else{
    $_SESSION['msg']="Enter Same Password";
    $_SESSION['type']="danger";
    header('location:../register.php');
}

}
if(isset($_POST['login'])){

    $email=htmlentities($_POST['email']);
    $pass=htmlentities($_POST['psw']);
    $password=md5($pass);

    
    
        $check="select *from user where email='$email' and password='$password'";
        $resultcheck=$conn->query($check);
    if($resultcheck->num_rows>0){
        $row=$resultcheck->fetch_assoc();
        $_SESSION['name']=$row['name'];
        $_SESSION['email']=$row['email'];

        $_SESSION['msg']="WelCome Dear";
        $_SESSION['type']="success";
        header('location:../user/');
    }else{
      
        $_SESSION['msg']="Your Login details are not matched";
        $_SESSION['type']="danger";
        header('location:../');
    } 
    }
    
  

?>