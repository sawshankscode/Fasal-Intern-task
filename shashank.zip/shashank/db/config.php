<?php 
error_reporting(0);
$server="localhost";
$username="root";
$password="";
$db="Shaswank";

$conn=new mysqli($server,$username,$password,$db);

if($conn->connect_error){
    die("<h2>Database Connection Failure : " . $conn->connect_error . "</h2><hr>");
}


?>