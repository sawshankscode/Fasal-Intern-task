<?php include'./db/config.php';
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="bg container">
     <div class="row">
         <div class="col-md-6">
             <img src="./img/bg.gif" alt="" style="width:100%">
         </div>
         <div class="col-md-6 mt-5">
         <form action="./auth/" method="post">

  <div class="container mt-5">
  <h4 class="text-center">Register Here</h4>
  <p class="text-center text-<?php echo $_SESSION['type']; $_SESSION['msg']=null ?>"><?php echo $_SESSION['msg']; $_SESSION['msg']=null?></p>
  <div class="form-group">
  <label for="uname"><b>Full Name</b></label>
    <input type="text" class="form-control" placeholder="Enter Username" name="uname" required>
  </div>
  
  <div class="form-group">
  <label for="email"><b>Email</b></label>
    <input type="email" class="form-control" placeholder="Enter Email" name="email" required>
  </div>
  <div class="form-group">
  <label for="pass1"><b>Create Password</b></label>
    <input type="password" class="form-control" placeholder="Create Password" name="pass1" required>
  </div>
  <div class="form-group">
  <label for="pass2"><b>Confirm Password</b></label>
    <input type="password" class="form-control" placeholder="confirm Password" name="pass2" required>
  </div>
    <div class="form-group">
    <input type="submit" name="register" class="form-control btn btn-primary" value="Register">
</div>

   
  </div>
  <div class="container mt-2 p-2 d-flex " >
    <div class="text-center mr-4" >Already have an account?  <a href="./">Login</a></div> 
  </div>

</form>
         </div>
     </div>
    </div>
</body>
</html>