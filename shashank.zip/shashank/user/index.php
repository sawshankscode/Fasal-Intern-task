<?php include'../db/config.php';
session_start();

if(!isset($_SESSION['name'])  && !isset($_SESSION['email'])){
    $_SESSION['msg']="Please Login First";
    header('location:../');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../style.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

  

    <div class="">
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <div class="container">
  <a class="navbar-brand" href="#">
    <img src="../img/bg.gif" alt="Logo" style="width:40px;">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link btn btn-success  text-white mr-3" href=""  data-toggle="modal" data-target="#addlist">Add Playlist</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-primary text-white mr-3" href="./upload" data-toggle="modal" data-target="#upload">Add Movie</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-danger text-white" href="./logout.php" >Logout</a>
      </li>
        
    </ul>
  </div>
  <form class="form-inline text-center" action="/action_page.php" >
    <input class="form-control mr-sm-2 w-75" type="text" placeholder="Search">
    <button class="btn btn-success" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
  </form> 
  
  </div>  
</nav>
        <div class="container">
        <h4 class="text-center p-3">Hello <?php echo $_SESSION['name']?></h4>
        <h4  class="alert text-center text-<?php echo $_SESSION['type']; $_SESSION['msg']=null; ?> " ><?php echo $_SESSION['msg']; $_SESSION['msg']=null; ?></h4>
        <ul class="nav nav-tabs">
        <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#feed"> Feed</a>
  </li>
        <?php 
                  
                  $check="select * from playlist";
                  $resultcheck=$conn->query($check);
                 while($row=$resultcheck->fetch_assoc()){ ?>
               
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#<?php echo $row['name']?>"> <?php echo $row['name']?></a>
  </li>
  <?php } ?>
</ul>

<!-- Tab panes -->
<div class="tab-content">
<div class="tab-pane container active" id="feed"> 

</div>  
<?php 

                  
                  $check="select * from playlist";
                  $resultcheck=$conn->query($check);
                 while($row=$resultcheck->fetch_assoc()){ 
                 $playname=$row['name']; 
                 
                 ?>
            <div class="tab-pane container " id="<?php echo $row['name']?>">   
                  
            <div class="container">
                <div class="row">
              <?php
                 $check11="select * from movies where playlist='$playname'";
                 $resultcheck11=$conn->query($check11);
                 if($resultcheck11->num_rows<=0){
                    echo "<h4 class='text-center mt-3'>Sorry! Your Playlist is Empty.</h4>";
                }else{
                while($rowss=$resultcheck11->fetch_assoc()){
                    
                    ?>
                <div class="col-md-3">
                <div class="card" style="width:100%">
                <video width="100%" height="240" controls>
  <source src="./movies/<?php echo $rowss['file']?>" type="video/mp4">
</video>
<div class="card-body">
<h4 class="card-title"><?php echo $rowss['name']?>  </h4>
<a href="./movies/<?php echo $rowss['file']?>" class="btn btn-primary">Play</a>
</div>
</div>
                </div>
                <?php } } ?>
                </div>
            </div> 
            </div>
  <?php } ?>
 
                 </div>

<!-- The Modal -->
<div class="modal fade " id="upload">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Upload Movie</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
      <form action="./upload/" method="post" enctype="multipart/form-data">
        <div class="form-group">
              <input class="form-control" type="text" name="moviename" placeholder="Enter Movie Name" id="">
        </div>
        <div class="form-group">
        <input type="text" value=""  class="form-control " name="tags" placeholder="Add tags" />
        <small>Add comma after every tag</small>
        </div>
        <div class="form-group">
              <select class="form-control" type="text" name="list" id="">
              <option value="" disabled selected> Please select playlist</option>
                  <?php 
                  
                  $check="select * from playlist";
                  $resultcheck=$conn->query($check);
                 while($row=$resultcheck->fetch_assoc()){ ?>
                <option value="<?php echo $row['name']?>">
                <?php echo $row['name']?>
                </option>
             <?php } ?>
           


</select>
        </div>
          <div class="form-group">
              <input class="form-control " type="file" name="movie" id="">
        </div>
        <div class="form-group">
              <input type="submit" class="form-control btn btn-success" name="save" id="" value="Upload">
        </div>
      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<!-- The Modal -->
<div class="modal fade" id="addlist">
  <div class="modal-dialog ">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Playlist</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
      <form action="./upload/" method="post" >
        <div class="form-group">
              <input class="form-control" type="text" name="listname" placeholder="Enter Play list Name" id="">
        </div>
     
        <div class="form-group">
              <input type="submit" class="form-control btn btn-success" name="addlist" id="" value="Add List">
        </div>
      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script src="./index.js"></script>
</body>
</html>
