<?php
session_start();
$_SESSION['name'] = false;
$_SESSION['email'] = false;
session_destroy();
header("location:../");

?>