<?php include'../../db/config.php';
session_start();

if(isset($_POST['save'])){
$user=$_SESSION['name'];
$name=htmlentities($_POST["moviename"]);
$tags=htmlentities($_POST['tags']);
$playlist=htmlentities($_POST['list']);
$movie=$_FILES['movie']['name'];
$Target = "../movies/".basename($_FILES['movie']['name']);


    $sql="insert into movies (name,tags,user,playlist,file) Values('$name','$tags','$user','$playlist','$movie')";
    $result = $conn->query($sql);
if($result){
    move_uploaded_file($_FILES["movie"]["tmp_name"], $Target);
    $_SESSION['msg']="Movie Uploaded Successfully";
    $_SESSION['type']="success";
    header('location:../');
}
else{
    $_SESSION['msg']="Sorry! There is Some Technical Issue !";
    $_SESSION['type']="danger";
    header('location:../');
} 


}
if(isset($_POST['addlist'])){

    $name=htmlentities($_POST['listname']);    
    
    $check="select name from playlist where name='$name'";
    $resultcheck=$conn->query($check);
if($resultcheck->num_rows>0){
    $_SESSION['msg']="Playlist Already Exist";
    $_SESSION['type']="warning";
    header('location:../');
  
}else{
    $sql="insert into playlist (name) Values('$name')";
    $result = $conn->query($sql);
if($result){
    $_SESSION['msg']="Playlist Added Successfully";
    $_SESSION['type']="success";
    header('location:../');
}
else{
    $_SESSION['msg']="Sorry! There is Some Technical Issue !";
    $_SESSION['type']="danger";
    header('location:../');
} 
}
    }
    
  

?>